# 00 — Proje Özeti & Master Prompt

## Amaç
Türkçe arayüzlü, koyu temalı, kişisel finans takip dashboard'u. Kullanıcı gelir/gider ekler; özet kartlar, donut chart ve işlem listesi gerçek zamanlı güncellenir. Bonus: üstte canlı borsa/döviz widget'ı (Apify Yahoo Finance).

## Tek Cümle Master Prompt
> React 19 + TypeScript + Vite + Tailwind 4 + Recharts ile, dark glassmorphism temalı, Türkçe arayüzlü kişisel finans takip uygulaması kur. Üstte sticky navbar (🏦 logo + ay/yıl + işlem sayacı), altında DAViData market widget banner'ı, sonra 3 sütun özet kart (Gelir / Gider / Net Bakiye), sonra 2 sütun ana alan (solda işlem listesi, sağda 320px sidebar'da donut grafik ve gelir/gider ekleme formu). State Dashboard component'inde local `useState`, ID `crypto.randomUUID()`, para `Intl.NumberFormat tr-TR TRY`. Renkler: bg `#09090B`, kart `#111116`, border `#27272A`, accent blue `#60A5FA`, green `#4ADE80`, red `#F87171`. Fontlar: Outfit (başlık) + DM Sans (gövde). Tüm bileşen stilleri inline (`React.CSSProperties`), CSS değişkenleri `:root`'ta tanımlı.

## Stack
| Katman | Seçim | Versiyon |
|---|---|---|
| Framework | React | 19.2.0 |
| Dil | TypeScript (strict) | 5.9.3 |
| Build | Vite | 7.3.1 |
| Stil | Tailwind CSS 4 + CSS vars | 4.2.0 |
| Chart | Recharts | 3.7.0 |
| İkon | lucide-react | 0.575.0 |
| Util | clsx + tailwind-merge | son |
| Market data | Apify (Yahoo Finance actor) | — |

## Klasör Ağacı (hedef)
```
finans-takip/
├── index.html                    # Google Fonts: Outfit + DM Sans
├── package.json
├── vite.config.ts                # react() + tailwindcss()
├── tsconfig.json / .app / .node
├── eslint.config.js
├── .env.local                    # VITE_APIFY_TOKEN=...
├── public/
└── src/
    ├── main.tsx                  # StrictMode + createRoot
    ├── App.tsx                   # <Dashboard />
    ├── index.css                 # CSS vars + Tailwind import + global reset
    ├── types/
    │   └── finance.ts            # Transaction, CategoryConfig
    ├── utils/
    │   └── categories.ts         # expense/income lists, formatCurrency, getCategoryConfig
    ├── lib/
    │   └── utils.ts              # cn() helper
    ├── hooks/
    │   └── useApifyMarket.ts     # 5dk cache'li Yahoo Finance fetch
    └── components/
        ├── Layout/
        │   ├── Dashboard.tsx     # state root, layout
        │   └── MarketWidget.tsx  # DAViData yerine canlı widget
        ├── Cards/
        │   ├── SummaryCard.tsx   # gelir/gider/bakiye
        │   └── TransactionCard.tsx
        ├── Forms/
        │   └── TransactionForm.tsx
        ├── Charts/
        │   └── ExpensePieChart.tsx
        └── Lists/
            └── TransactionList.tsx
```

## Özellikler
- [x] Gider ekle (8 kategori) / Gelir ekle (4 kategori) — sekme switch
- [x] Özet kartlar: Toplam Gelir, Toplam Gider, Net Bakiye (negatifte kırmızı)
- [x] Donut grafik: kategori bazlı dağılım + tooltip + legend
- [x] İşlem listesi: yenıden eskiye sıralı, hover'da sil (iki aşamalı confirm)
- [x] Sticky navbar + ay/yıl + işlem sayacı
- [x] Empty state'ler (📋 / 📊 emoji + Türkçe mesaj)
- [x] Apify market widget: BIST / USD-TRY / Altın / BTC fiyat + 24h % değişim
- [ ] Persistence yok (sayfa yenilenince sıfırlanır — footer'da uyarı)

## Sıra
00 → 01 (setup) → 02 (design system) → 03 (types) → 04 (Dashboard) → 05 (SummaryCard) → 06 (Form) → 07 (List + Card) → 08 (PieChart) → 09 (Apify widget). Her dosya kendi başına çalıştırılabilir.

## Bağlantılı dosyalar
- [01-setup.md](./01-setup.md) — kurulum komutları
- [09-apify-market-widget.md](./09-apify-market-widget.md) — Apify entegrasyonu
