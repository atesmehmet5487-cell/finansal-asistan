# 08 — Expense Pie Chart (Donut + Legend)

## Amaç
Recharts donut grafik: kategoriye göre gelir/gider dağılımı + tab switch + ortada toplam + altta liste.

## Dosya
`src/components/Charts/ExpensePieChart.tsx`

## Görsel
```
┌────────────────────────────────────┐
│ Dağılım            [Gider] Gelir   │  ← header + segmented control
├────────────────────────────────────┤
│           ╭───────╮                │
│         /           \              │
│        |  TOPLAM    |              │  ← Center label
│        |  GİDER     |              │
│        |  ₺452,50   |              │
│         \           /              │
│           ╰───────╯                │
├────────────────────────────────────┤
│ 🔴 Yeme-İçme    %35    ₺158,75     │  ← Legend satırları
│ 🟣 Ulaşım       %28    ₺126,70     │
│ 🟦 Faturalar    %22    ₺99,55      │
│ ...                                │
└────────────────────────────────────┘
```

## Detaylar
- **Donut**: innerRadius 55, outerRadius 85, paddingAngle 2, strokeWidth 0, animationDuration 450ms
- **Tab**: segmented control (bg `var(--bg)`, aktif `var(--bg-hover)` + variant rengi)
- **Center**: `<g>` içinde 2 satır text — üstte uppercase başlık (TOPLAM GELİR/GİDER), altta tutar
- **Custom Tooltip**: kategori icon + name + tutar + %
- **Legend**: 6px renkli daire + kategori adı + yüzde + tutar
- **Empty state**: 📊 + "Henüz veri yok"
- **Data grouping**: aynı kategorideki işlemler `Map<string, number>` ile toplanır, total üzerinden % hesaplanır, value'ya göre desc sıralanır

## src/components/Charts/ExpensePieChart.tsx (TAM)
```tsx
import { useState } from "react";
import { PieChart, Pie, Cell, Tooltip, ResponsiveContainer } from "recharts";
import type { Transaction } from "../../types/finance";
import { getCategoryConfig, formatCurrency } from "../../utils/categories";

interface Props { transactions: Transaction[]; }
type Tab = "expense" | "income";

interface Entry { name: string; value: number; color: string; icon: string; pct: number; }

const Tip = ({ active, payload }: { active?: boolean; payload?: { payload: Entry }[] }) => {
  if (!active || !payload?.length) return null;
  const e = payload[0].payload;
  return (
    <div style={{
      background: "var(--bg-card)", border: "1px solid var(--border)",
      borderRadius: "8px", padding: "0.625rem 0.875rem",
      boxShadow: "0 4px 16px rgba(0,0,0,0.4)",
    }}>
      <p style={{ fontSize: "0.75rem", color: "var(--text-muted)", marginBottom: "0.25rem" }}>
        {e.icon} {e.name}
      </p>
      <p style={{ fontFamily: "'Outfit', sans-serif", fontWeight: 700, color: e.color, fontSize: "1rem" }}>
        {formatCurrency(e.value)}
      </p>
      <p style={{ fontSize: "0.6875rem", color: "var(--text-dim)", marginTop: "0.125rem" }}>
        %{e.pct.toFixed(1)}
      </p>
    </div>
  );
};

const Center = ({ viewBox, total, tab }: { viewBox?: { cx: number; cy: number }; total: number; tab: Tab }) => {
  const { cx, cy } = viewBox || { cx: 0, cy: 0 };
  const color = tab === "income" ? "var(--green)" : "var(--red)";
  return (
    <g>
      <text x={cx} y={cy - 10} textAnchor="middle" fill="#71717A" fontSize={10}
            fontFamily="'DM Sans', sans-serif" letterSpacing="0.06em">
        {tab === "income" ? "TOPLAM GELİR" : "TOPLAM GİDER"}
      </text>
      <text x={cx} y={cy + 10} textAnchor="middle" fill={color} fontSize={14}
            fontWeight={700} fontFamily="'Outfit', sans-serif">
        {formatCurrency(total)}
      </text>
    </g>
  );
};

export default function ExpensePieChart({ transactions }: Props) {
  const [tab, setTab] = useState<Tab>("expense");

  const data: Entry[] = (() => {
    const map = new Map<string, number>();
    transactions
      .filter(t => t.type === tab)
      .forEach(t => map.set(t.category, (map.get(t.category) || 0) + t.amount));
    const total = Array.from(map.values()).reduce((s, v) => s + v, 0);
    return Array.from(map.entries()).map(([name, value]) => {
      const cfg = getCategoryConfig(name, tab);
      return {
        name, value,
        color: cfg?.color || "#71717A",
        icon: cfg?.icon || "•",
        pct: total > 0 ? (value / total) * 100 : 0,
      };
    }).sort((a, b) => b.value - a.value);
  })();

  const total = data.reduce((s, d) => s + d.value, 0);

  return (
    <div style={{
      background: "var(--bg-card)", border: "1px solid var(--border)",
      borderRadius: "12px", overflow: "hidden",
    }}>
      {/* Header + tab switch */}
      <div style={{
        display: "flex", alignItems: "center", justifyContent: "space-between",
        padding: "1rem 1.25rem", borderBottom: "1px solid var(--border)",
      }}>
        <span style={{ fontSize: "0.875rem", fontWeight: 600, color: "var(--text)" }}>Dağılım</span>
        <div style={{ display: "flex", background: "var(--bg)", borderRadius: "6px", padding: "2px", gap: "2px" }}>
          {(["expense", "income"] as Tab[]).map(t => {
            const active = tab === t;
            const c = t === "income" ? "var(--green)" : "var(--red)";
            return (
              <button key={t} onClick={() => setTab(t)} style={{
                padding: "0.25rem 0.625rem", borderRadius: "5px", border: "none",
                background: active ? "var(--bg-hover)" : "transparent",
                color: active ? c : "var(--text-muted)",
                fontFamily: "'DM Sans', sans-serif",
                fontWeight: active ? 600 : 400,
                fontSize: "0.75rem", cursor: "pointer", transition: "all 0.15s",
              }}>
                {t === "income" ? "Gelir" : "Gider"}
              </button>
            );
          })}
        </div>
      </div>

      {data.length === 0 ? (
        <div style={{ padding: "3rem 1.25rem", textAlign: "center" }}>
          <p style={{ fontSize: "1.5rem", marginBottom: "0.5rem" }}>📊</p>
          <p style={{ color: "var(--text-muted)", fontSize: "0.8125rem" }}>Henüz veri yok</p>
        </div>
      ) : (
        <>
          <div style={{ padding: "0.75rem 1.25rem 0" }}>
            <ResponsiveContainer width="100%" height={200}>
              <PieChart>
                <Pie data={data} cx="50%" cy="50%" innerRadius={55} outerRadius={85}
                     paddingAngle={2} dataKey="value"
                     animationBegin={0} animationDuration={450} strokeWidth={0}>
                  {data.map((e, i) => <Cell key={i} fill={e.color} />)}
                  <Center total={total} tab={tab} />
                </Pie>
                <Tooltip content={<Tip />} />
              </PieChart>
            </ResponsiveContainer>
          </div>

          <div style={{
            padding: "0.75rem 1.25rem 1.25rem",
            display: "flex", flexDirection: "column", gap: "0.375rem",
          }}>
            {data.map(e => (
              <div key={e.name} style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                <div style={{ display: "flex", alignItems: "center", gap: "0.5rem" }}>
                  <div style={{
                    width: "6px", height: "6px", borderRadius: "50%",
                    background: e.color, flexShrink: 0,
                  }} />
                  <span style={{ fontSize: "0.8125rem", color: "var(--text-muted)" }}>{e.name}</span>
                </div>
                <div style={{ display: "flex", alignItems: "center", gap: "0.625rem" }}>
                  <span style={{
                    fontSize: "0.6875rem", color: "var(--text-dim)",
                    fontFamily: "'Outfit', sans-serif",
                  }}>%{e.pct.toFixed(0)}</span>
                  <span style={{
                    fontSize: "0.8125rem", fontWeight: 600, color: "var(--text)",
                    fontFamily: "'Outfit', sans-serif",
                  }}>{formatCurrency(e.value)}</span>
                </div>
              </div>
            ))}
          </div>
        </>
      )}
    </div>
  );
}
```

## Doğrulama
- Birkaç işlem ekledikten sonra donut grafik dilimlerle dolar
- Mouse dilim üzerine gelince kategori adı + tutar + % gösterilir
- Sekme değişince donut ve legend güncellenir
- Boşken 📊 ile empty state

Sonraki: [09-apify-market-widget.md](./09-apify-market-widget.md)
