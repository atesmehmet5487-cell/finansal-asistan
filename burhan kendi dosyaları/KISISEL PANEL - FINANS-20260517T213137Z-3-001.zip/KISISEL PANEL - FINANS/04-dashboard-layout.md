# 04 — Dashboard Layout (State Root)

## Amaç
Sticky navbar + sayfa içerik düzeni + tek state container. Tüm child component'ler buradan beslenir.

## Dosya
`src/components/Layout/Dashboard.tsx`

## Düzen
```
┌──────────────────────────────────────────────────────────┐
│ NAVBAR (sticky, blur)   🏦 Finans Takip   📅 Mayıs 2026  │
├──────────────────────────────────────────────────────────┤
│ ┌───────────────── DAViData / MarketWidget ───────────┐  │
│ ├──────────────────────────────────────────────────────┤  │
│ │ Gelir Kartı │ Gider Kartı │ Net Bakiye Kartı       │  │
│ ├─────────────────────────────────┬────────────────────┤  │
│ │                                 │   ExpensePieChart  │  │
│ │      TransactionList            │  ──────────────    │  │
│ │      (flex 1, sol)              │   TransactionForm  │  │
│ │                                 │   (320px, sağ)     │  │
│ └─────────────────────────────────┴────────────────────┘  │
│         "Veriler yerel bellekte tutulur..."               │
└──────────────────────────────────────────────────────────┘
```

## State
```ts
const [transactions, setTransactions] = useState<Transaction[]>([]);
const add = (tx: Transaction) => setTransactions(p => [tx, ...p]);
const del = (id: string)       => setTransactions(p => p.filter(t => t.id !== id));
const income  = transactions.filter(t => t.type === "income").reduce((s, t) => s + t.amount, 0);
const expense = transactions.filter(t => t.type === "expense").reduce((s, t) => s + t.amount, 0);
const balance = income - expense;
```

## src/components/Layout/Dashboard.tsx (TAM)
```tsx
import { useState } from "react";
import { TrendingUp, TrendingDown, Wallet } from "lucide-react";
import type { Transaction } from "../../types/finance";
import SummaryCard from "../Cards/SummaryCard";
import TransactionForm from "../Forms/TransactionForm";
import ExpensePieChart from "../Charts/ExpensePieChart";
import TransactionList from "../Lists/TransactionList";
import MarketWidget from "./MarketWidget"; // 09'da yazılacak (veya DAViDataPanel placeholder)

export default function Dashboard() {
  const [transactions, setTransactions] = useState<Transaction[]>([]);

  const add = (tx: Transaction) => setTransactions(p => [tx, ...p]);
  const del = (id: string) => setTransactions(p => p.filter(t => t.id !== id));

  const income  = transactions.filter(t => t.type === "income").reduce((s, t) => s + t.amount, 0);
  const expense = transactions.filter(t => t.type === "expense").reduce((s, t) => s + t.amount, 0);
  const balance = income - expense;

  const month = new Date().toLocaleDateString("tr-TR", { month: "long", year: "numeric" });

  return (
    <div style={{ minHeight: "100vh", background: "var(--bg)" }}>

      {/* ── Sticky navbar ───────────────────────────────────── */}
      <nav style={{
        position: "sticky", top: 0, zIndex: 50,
        background: "rgba(9,9,11,0.85)", backdropFilter: "blur(12px)",
        borderBottom: "1px solid var(--border)",
        display: "flex", alignItems: "center", justifyContent: "space-between",
        padding: "0 1.5rem", height: "52px",
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: "0.75rem" }}>
          <div style={{
            width: "26px", height: "26px", borderRadius: "7px",
            background: "var(--blue-dim)", border: "1px solid var(--blue-border)",
            display: "flex", alignItems: "center", justifyContent: "center", fontSize: "0.875rem",
          }}>🏦</div>
          <span style={{
            fontFamily: "'Outfit', sans-serif", fontWeight: 700, fontSize: "0.9375rem",
            color: "var(--text)", letterSpacing: "-0.02em",
          }}>
            Finans Takip
          </span>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: "0.625rem" }}>
          <span style={{ fontSize: "0.75rem", color: "var(--text-muted)" }}>📅 {month}</span>
          {transactions.length > 0 && (
            <span style={{
              fontSize: "0.6875rem", fontWeight: 600,
              background: "var(--blue-dim)", border: "1px solid var(--blue-border)",
              color: "var(--blue)", borderRadius: "5px", padding: "0.1875rem 0.5rem",
            }}>
              {transactions.length} işlem
            </span>
          )}
        </div>
      </nav>

      {/* ── Body ──────────────────────────────────────────────── */}
      <div style={{ maxWidth: "1280px", margin: "0 auto", padding: "1.5rem" }}>

        <div style={{ marginBottom: "1.25rem" }}>
          <MarketWidget />
        </div>

        {/* Summary row (3 col) */}
        <div className="grid-3" style={{
          display: "grid", gridTemplateColumns: "repeat(3,1fr)",
          gap: "0.75rem", marginBottom: "1.25rem",
        }}>
          <SummaryCard title="Toplam Gelir"  amount={income}  icon={<TrendingUp   size={15} color="var(--green)" />} variant="income"  />
          <SummaryCard title="Toplam Gider"  amount={expense} icon={<TrendingDown size={15} color="var(--red)"   />} variant="expense" />
          <SummaryCard title="Net Bakiye"    amount={balance} icon={<Wallet       size={15} color="var(--blue)"  />} variant="balance" />
        </div>

        {/* Two-column main (left list, right sidebar 320px) */}
        <div className="grid-2" style={{
          display: "grid", gridTemplateColumns: "1fr 320px",
          gap: "0.75rem", alignItems: "start",
        }}>
          <TransactionList transactions={transactions} onDelete={del} />

          <div style={{ display: "flex", flexDirection: "column", gap: "0.75rem" }}>
            <ExpensePieChart transactions={transactions} />
            <TransactionForm onAdd={add} />
          </div>
        </div>

        <p style={{
          textAlign: "center", marginTop: "2rem",
          fontSize: "0.6875rem", color: "var(--text-dim)",
        }}>
          Veriler yerel bellekte tutulur — sayfa yenilenince sıfırlanır
        </p>
      </div>
    </div>
  );
}
```

## Notlar
- `grid-3` ve `grid-2` class adları `index.css` media query'leri için (mobilde 1 sütun).
- Navbar `position: sticky` — scroll'da üstte kalır, `backdrop-filter` blur efekti verir.
- Footer notu zorunlu — kullanıcı persistence olmadığını bilmeli.

## Doğrulama
`npm run dev` → koyu sayfada üstte navbar görünür, ortada (henüz yazılmamış) child component'lerden hata gelir. Sonraki adımlarda doldurulacak.

Sonraki: [05-summary-cards.md](./05-summary-cards.md)
