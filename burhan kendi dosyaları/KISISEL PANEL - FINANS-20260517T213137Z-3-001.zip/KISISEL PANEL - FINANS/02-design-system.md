# 02 — Design System

## Amaç
Tüm görsel kimlik tek yerden: CSS değişkenleri, font, global reset, responsive grid kuralları.

## Felsefe
- **Dark glassmorphism**: derin lacivert arka plan, ince border, navbar'da `backdrop-filter: blur(12px)`
- **Inline stil**: tüm component'ler `React.CSSProperties` kullanır, Tailwind utility class kullanmaz (sadece `@import "tailwindcss"` reset için)
- **Renkler değişken üzerinden**: `var(--green)`, `var(--red)`, `var(--blue)` — variant'lar bunlarla değişir

## Renk Paleti

| Token | Hex | Kullanım |
|---|---|---|
| `--bg` | `#09090B` | Sayfa arka planı |
| `--bg-card` | `#111116` | Kart, panel arka planı |
| `--bg-hover` | `#18181F` | Hover state |
| `--border` | `#27272A` | Standart kenarlık |
| `--border-light` | `#1C1C22` | Liste içi divider |
| `--text` | `#FAFAFA` | Birincil yazı |
| `--text-muted` | `#71717A` | İkincil yazı |
| `--text-dim` | `#3F3F46` | En soluk yazı |
| `--blue` | `#60A5FA` | Net Bakiye, MCP badge |
| `--blue-dim` | `rgba(96,165,250,0.08)` | Mavi accent arkaplan |
| `--blue-border` | `rgba(96,165,250,0.18)` | Mavi accent kenar |
| `--green` | `#4ADE80` | Gelir |
| `--green-dim` | `rgba(74,222,128,0.08)` | Yeşil arkaplan |
| `--green-border` | `rgba(74,222,128,0.18)` | Yeşil kenar |
| `--red` | `#F87171` | Gider, negatif bakiye |
| `--red-dim` | `rgba(248,113,113,0.08)` | Kırmızı arkaplan |
| `--red-border` | `rgba(248,113,113,0.18)` | Kırmızı kenar |

## Tipografi
- **Başlık** (h1-h4, tutar, sayı): `'Outfit', sans-serif`, weight 600-700, letter-spacing `-0.02em` ila `-0.03em`
- **Gövde**: `'DM Sans', sans-serif`, weight 400-600
- **Base font-size**: 14px
- **Uppercase etiketler**: letter-spacing `0.06em`

## src/index.css (TAM)
```css
@import "tailwindcss";

:root {
  --bg:           #09090B;
  --bg-card:      #111116;
  --bg-hover:     #18181F;
  --border:       #27272A;
  --border-light: #1C1C22;

  --text:         #FAFAFA;
  --text-muted:   #71717A;
  --text-dim:     #3F3F46;

  --blue:         #60A5FA;
  --blue-dim:     rgba(96, 165, 250, 0.08);
  --blue-border:  rgba(96, 165, 250, 0.18);

  --green:        #4ADE80;
  --green-dim:    rgba(74, 222, 128, 0.08);
  --green-border: rgba(74, 222, 128, 0.18);

  --red:          #F87171;
  --red-dim:      rgba(248, 113, 113, 0.08);
  --red-border:   rgba(248, 113, 113, 0.18);
}

*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

html, body, #root {
  background: var(--bg);
  color: var(--text);
  font-family: 'DM Sans', system-ui, sans-serif;
  font-size: 14px;
  line-height: 1.5;
  min-height: 100vh;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

h1, h2, h3, h4 { font-family: 'Outfit', sans-serif; letter-spacing: -0.02em; }

::-webkit-scrollbar { width: 4px; }
::-webkit-scrollbar-track { background: transparent; }
::-webkit-scrollbar-thumb { background: var(--border); border-radius: 2px; }

input[type="number"]::-webkit-inner-spin-button,
input[type="number"]::-webkit-outer-spin-button { -webkit-appearance: none; }
input[type="number"] { -moz-appearance: textfield; }

@keyframes fadeUp {
  from { opacity: 0; transform: translateY(5px); }
  to   { opacity: 1; transform: translateY(0); }
}
.fade-up { animation: fadeUp 0.2s ease forwards; }

@media (max-width: 640px) {
  .grid-3 { grid-template-columns: 1fr !important; }
  .grid-2 { grid-template-columns: 1fr !important; }
}
@media (min-width: 641px) and (max-width: 900px) {
  .grid-2 { grid-template-columns: 1fr !important; }
}
```

## Standart Kart Stili
Her kartta tutarlı: `bg-card` + `border` + `border-radius: 12px`.
```ts
const cardStyle: React.CSSProperties = {
  background: "var(--bg-card)",
  border: "1px solid var(--border)",
  borderRadius: "12px",
  overflow: "hidden",
};
```

## Standart Spacing
- Sayfa padding: `1.5rem`
- Grid gap: `0.75rem` (12px)
- Kart iç padding: `1rem 1.25rem` veya `1.25rem`
- Sticky navbar yükseklik: `52px`

## Doğrulama
- Tarayıcı koyu (#09090B) açılıyor
- Outfit/DM Sans yükleniyor (DevTools → Network → fonts.googleapis)
- `<h1>Test</h1>` koysan Outfit görünür

Sonraki: [03-types-and-utils.md](./03-types-and-utils.md)
