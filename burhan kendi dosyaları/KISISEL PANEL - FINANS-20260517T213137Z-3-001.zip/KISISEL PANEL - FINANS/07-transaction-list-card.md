# 07 — Transaction List + Card

## Amaç
İşlem listesi (sıralı + sayaç + empty state) ve liste içinde her bir işlem satırı (hover'da sil butonu, iki aşamalı confirm).

## Dosyalar
- `src/components/Lists/TransactionList.tsx`
- `src/components/Cards/TransactionCard.tsx`

## Liste Görseli
```
┌────────────────────────────────────────────┐
│ İşlemler                              [3]  │
├────────────────────────────────────────────┤
│ 🍔  Öğle yemeği                  +₺42,00   │
│     Yeme-İçme · 15 May                     │
│ ────────────────────────────────────────── │
│ 💰  Maaş                       +₺25.000,00 │
│     Maaş · 14 May                          │
│ ...                                        │
└────────────────────────────────────────────┘
```

Empty state:
```
        📋
   Henüz işlem yok
 Sağdaki formdan ekleyebilirsiniz
```

## src/components/Lists/TransactionList.tsx (TAM)
```tsx
import type { Transaction } from "../../types/finance";
import TransactionCard from "../Cards/TransactionCard";

interface Props { transactions: Transaction[]; onDelete: (id: string) => void; }

export default function TransactionList({ transactions, onDelete }: Props) {
  const sorted = [...transactions].sort((a, b) => b.createdAt - a.createdAt);

  return (
    <div style={{
      background: "var(--bg-card)", border: "1px solid var(--border)",
      borderRadius: "12px", overflow: "hidden",
    }}>
      <div style={{
        display: "flex", alignItems: "center", justifyContent: "space-between",
        padding: "1rem 1.25rem", borderBottom: "1px solid var(--border)",
      }}>
        <span style={{ fontSize: "0.875rem", fontWeight: 600, color: "var(--text)" }}>İşlemler</span>
        {transactions.length > 0 && (
          <span style={{
            fontSize: "0.75rem", color: "var(--text-muted)",
            background: "var(--bg)", border: "1px solid var(--border)",
            borderRadius: "5px", padding: "0.1875rem 0.5rem",
          }}>
            {transactions.length}
          </span>
        )}
      </div>

      {sorted.length === 0 ? (
        <div style={{ padding: "3rem 1.25rem", textAlign: "center" }}>
          <p style={{ fontSize: "1.5rem", marginBottom: "0.5rem" }}>📋</p>
          <p style={{ color: "var(--text-muted)", fontSize: "0.8125rem" }}>Henüz işlem yok</p>
          <p style={{ color: "var(--text-dim)", fontSize: "0.75rem", marginTop: "0.25rem" }}>
            Sağdaki formdan ekleyebilirsiniz
          </p>
        </div>
      ) : (
        <div>
          {sorted.map((tx, i) => (
            <div key={tx.id}>
              <TransactionCard transaction={tx} onDelete={onDelete} />
              {i < sorted.length - 1 && (
                <div style={{ height: "1px", background: "var(--border-light)", margin: "0 1rem" }} />
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
```

## Kart Davranışı
- **Hover**: arkaplan `var(--bg-hover)`, sil butonu görünür hale gelir (opacity 0 → 1)
- **Mouse leave**: confirm state'i sıfırlanır
- **Sil butonu (1. tıklama)**: yerine ✓ / ✕ butonları çıkar
- **✓ tıklama**: `onDelete(id)` çağrılır
- **✕ tıklama**: confirm iptal
- **Icon rengi**: kategori rengine 12 alpha eklenerek (`${color}12`) yumuşak doldurma

## src/components/Cards/TransactionCard.tsx (TAM)
```tsx
import { useState } from "react";
import { Trash2 } from "lucide-react";
import type { Transaction } from "../../types/finance";
import { getCategoryConfig, formatCurrency } from "../../utils/categories";

interface Props { transaction: Transaction; onDelete: (id: string) => void; }

export default function TransactionCard({ transaction, onDelete }: Props) {
  const [confirm, setConfirm] = useState(false);
  const [hovered, setHovered] = useState(false);
  const cfg = getCategoryConfig(transaction.category, transaction.type);
  const isIncome = transaction.type === "income";

  return (
    <div
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => { setHovered(false); setConfirm(false); }}
      style={{
        display: "flex", alignItems: "center", gap: "0.75rem",
        padding: "0.6875rem 1rem",
        background: hovered ? "var(--bg-hover)" : "transparent",
        transition: "background 0.1s",
        cursor: "default",
      }}
    >
      <div style={{
        width: "2rem", height: "2rem", borderRadius: "8px",
        background: `${cfg?.color || "#71717A"}12`,
        display: "flex", alignItems: "center", justifyContent: "center",
        fontSize: "0.9375rem", flexShrink: 0,
      }}>
        {cfg?.icon || "•"}
      </div>

      <div style={{ flex: 1, minWidth: 0 }}>
        <p style={{
          fontSize: "0.875rem", fontWeight: 500, color: "var(--text)",
          whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis",
        }}>
          {transaction.description || transaction.category}
        </p>
        <p style={{ fontSize: "0.6875rem", color: "var(--text-muted)", marginTop: "0.125rem" }}>
          {transaction.category} · {new Date(transaction.date).toLocaleDateString("tr-TR", { day: "numeric", month: "short" })}
        </p>
      </div>

      <div style={{ display: "flex", alignItems: "center", gap: "0.625rem", flexShrink: 0 }}>
        <span style={{
          fontFamily: "'Outfit', sans-serif", fontWeight: 700, fontSize: "0.9375rem",
          color: isIncome ? "var(--green)" : "var(--red)",
        }}>
          {isIncome ? "+" : "−"}{formatCurrency(transaction.amount)}
        </span>

        <div style={{ opacity: hovered ? 1 : 0, transition: "opacity 0.1s", width: "1.625rem" }}>
          {!confirm ? (
            <button
              aria-label="Sil"
              onClick={() => setConfirm(true)}
              style={{
                width: "1.625rem", height: "1.625rem", borderRadius: "6px",
                background: "transparent", border: "1px solid var(--border)",
                color: "var(--text-muted)", cursor: "pointer",
                display: "flex", alignItems: "center", justifyContent: "center",
                transition: "all 0.1s",
              }}
              onMouseEnter={e => {
                e.currentTarget.style.borderColor = "var(--red)";
                e.currentTarget.style.color = "var(--red)";
                e.currentTarget.style.background = "var(--red-dim)";
              }}
              onMouseLeave={e => {
                e.currentTarget.style.borderColor = "var(--border)";
                e.currentTarget.style.color = "var(--text-muted)";
                e.currentTarget.style.background = "transparent";
              }}
            >
              <Trash2 size={11} />
            </button>
          ) : (
            <div style={{ display: "flex", gap: "0.25rem" }}>
              <button onClick={() => onDelete(transaction.id)} style={{
                width: "1.625rem", height: "1.625rem", borderRadius: "6px",
                background: "var(--red-dim)", border: "1px solid var(--red-border)",
                color: "var(--red)", cursor: "pointer", fontSize: "0.625rem", fontWeight: 700,
              }}>✓</button>
              <button onClick={() => setConfirm(false)} style={{
                width: "1.625rem", height: "1.625rem", borderRadius: "6px",
                background: "transparent", border: "1px solid var(--border)",
                color: "var(--text-muted)", cursor: "pointer", fontSize: "0.625rem",
              }}>✕</button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
```

## Doğrulama
- Yeni eklenen işlem listenin en üstüne çıkar
- Satıra hover edince arkaplan açılır, sağda çöp kutusu belirir
- Çöp kutusuna tıklayınca ✓/✕ çıkar; ✓ silinir, ✕ iptal, mouse alınca confirm sıfırlanır
- Tarih Türkçe gösterilir: "15 May"
- Gelir → yeşil + işareti, Gider → kırmızı − işareti

Sonraki: [08-pie-chart.md](./08-pie-chart.md)
