# 03 — Types, Categories & Utils

## Amaç
Veri modeli, kategori sabitleri ve yardımcı fonksiyonlar — tüm uygulama bunlara bağlı.

## src/types/finance.ts
```ts
export type TransactionType = "income" | "expense";

export interface Transaction {
  id: string;
  type: TransactionType;
  category: string;
  amount: number;
  description: string;
  date: string;       // "YYYY-MM-DD"
  createdAt: number;  // Date.now()
}

export interface CategoryConfig {
  name: string;
  color: string;  // hex
  icon: string;   // emoji
}
```

## src/utils/categories.ts (TAM)
```ts
import type { CategoryConfig } from "../types/finance";

export const expenseCategories: CategoryConfig[] = [
  { name: "Yeme-İçme", color: "#FB7185", icon: "🍔" },
  { name: "Ulaşım",    color: "#A78BFA", icon: "🚗" },
  { name: "Alışveriş", color: "#22D3EE", icon: "🛍️" },
  { name: "Faturalar", color: "#FB923C", icon: "📄" },
  { name: "Eğlence",   color: "#F472B6", icon: "🎮" },
  { name: "Sağlık",    color: "#4ADE80", icon: "💊" },
  { name: "Eğitim",    color: "#60A5FA", icon: "📚" },
  { name: "Diğer",     color: "#94A3B8", icon: "📌" },
];

export const incomeCategories: CategoryConfig[] = [
  { name: "Maaş",        color: "#34D399", icon: "💰" },
  { name: "Freelance",   color: "#2DD4BF", icon: "💻" },
  { name: "Yatırım",     color: "#FBBF24", icon: "📈" },
  { name: "Diğer Gelir", color: "#A3E635", icon: "🎁" },
];

export const getCategoryConfig = (
  categoryName: string,
  type: "income" | "expense"
): CategoryConfig | undefined => {
  const list = type === "income" ? incomeCategories : expenseCategories;
  return list.find((c) => c.name === categoryName);
};

export const formatCurrency = (amount: number): string => {
  return new Intl.NumberFormat("tr-TR", {
    style: "currency",
    currency: "TRY",
    minimumFractionDigits: 2,
  }).format(amount);
};
```

## src/lib/utils.ts
```ts
import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}
```

## Kurallar
- **ID üretimi**: hep `crypto.randomUUID()` (modern tarayıcı)
- **Tarih**: `new Date().toISOString().split("T")[0]` → "2026-05-16"
- **Sıralama**: `transactions.sort((a, b) => b.createdAt - a.createdAt)` (yeni → eski)
- **Para formatı**: dünyada her yerde `formatCurrency(amount)` çağır, asla manuel string

## Test Snippet (geçici)
```tsx
// Browser console'da:
import { formatCurrency } from "./utils/categories";
formatCurrency(1234.5)  // → "₺1.234,50"
```

Sonraki: [04-dashboard-layout.md](./04-dashboard-layout.md)
