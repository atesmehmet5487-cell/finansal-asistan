# 06 — Transaction Form (Gelir/Gider Ekleme)

## Amaç
Sekme switch'li form: Gider/Gelir, kategori dropdown, ₺ prefixli tutar, opsiyonel açıklama, validation, success state.

## Dosya
`src/components/Forms/TransactionForm.tsx`

## Görsel
```
┌────────────────────────────────────┐
│ [Gider Ekle]  Gelir Ekle           │  ← tab, aktif olan altında 2px renk çizgi
├────────────────────────────────────┤
│ Kategori                           │
│ [Seçin... ▾]                       │
│                                    │
│ Tutar                              │
│ [₺ 0,00         ]                  │
│                                    │
│ Açıklama (opsiyonel)               │
│ [Örn: Öğle yemeği]                 │
│                                    │
│ [    Gider Ekle    ]               │  ← variant rengi
└────────────────────────────────────┘
```

## Davranış
- **Tab değişimi**: `type` değişir, kategori listesi `expenseCategories` ↔ `incomeCategories`, kategori state'i sıfırlanır
- **Validation**: kategori boş veya tutar ≤ 0 → kırmızı border + inline mesaj
- **Submit**: yeni Transaction oluştur, `onAdd(tx)` çağır, formu reset et, 1.8s "✓ Kaydedildi" göster
- **Focus**: input'lara odaklanılınca border `var(--blue)`'ya geçer
- **Number input**: spinner gizlenir (CSS'te tanımlı), `step="0.01"`, `min="0.01"`

## Input Stili Yardımcısı
```ts
const inputStyle = (focus: boolean, error?: string): React.CSSProperties => ({
  width: "100%",
  background: "var(--bg)",
  border: `1px solid ${error ? "var(--red)" : focus ? "var(--blue)" : "var(--border)"}`,
  borderRadius: "8px",
  padding: "0.5625rem 0.75rem",
  color: "var(--text)",
  fontFamily: "'DM Sans', sans-serif",
  fontSize: "0.875rem",
  outline: "none",
  transition: "border-color 0.15s",
});
```

## src/components/Forms/TransactionForm.tsx (TAM)
```tsx
import { useState } from "react";
import type { Transaction, TransactionType } from "../../types/finance";
import { expenseCategories, incomeCategories } from "../../utils/categories";

interface TransactionFormProps {
  onAdd: (transaction: Transaction) => void;
}

const inputStyle = (focus: boolean, error?: string): React.CSSProperties => ({
  width: "100%",
  background: "var(--bg)",
  border: `1px solid ${error ? "var(--red)" : focus ? "var(--blue)" : "var(--border)"}`,
  borderRadius: "8px",
  padding: "0.5625rem 0.75rem",
  color: "var(--text)",
  fontFamily: "'DM Sans', sans-serif",
  fontSize: "0.875rem",
  outline: "none",
  transition: "border-color 0.15s",
});

export default function TransactionForm({ onAdd }: TransactionFormProps) {
  const [type, setType] = useState<TransactionType>("expense");
  const [category, setCategory] = useState("");
  const [amount, setAmount] = useState("");
  const [description, setDescription] = useState("");
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [success, setSuccess] = useState(false);
  const [focusField, setFocusField] = useState("");

  const categories = type === "income" ? incomeCategories : expenseCategories;

  const validate = () => {
    const e: Record<string, string> = {};
    if (!category) e.category = "Seçiniz";
    if (!amount || parseFloat(amount) <= 0) e.amount = "Geçersiz tutar";
    setErrors(e);
    return !Object.keys(e).length;
  };

  const handleSubmit = (ev: React.FormEvent) => {
    ev.preventDefault();
    if (!validate()) return;
    onAdd({
      id: crypto.randomUUID(),
      type,
      category,
      amount: parseFloat(amount),
      description: description.trim(),
      date: new Date().toISOString().split("T")[0],
      createdAt: Date.now(),
    });
    setCategory(""); setAmount(""); setDescription(""); setErrors({});
    setSuccess(true);
    setTimeout(() => setSuccess(false), 1800);
  };

  return (
    <div style={{ background: "var(--bg-card)", border: "1px solid var(--border)", borderRadius: "12px" }}>
      {/* Tab header */}
      <div style={{ display: "flex", borderBottom: "1px solid var(--border)" }}>
        {(["expense", "income"] as TransactionType[]).map((t) => {
          const active = type === t;
          const color = t === "income" ? "var(--green)" : "var(--red)";
          return (
            <button
              key={t}
              type="button"
              onClick={() => { setType(t); setCategory(""); setErrors({}); }}
              style={{
                flex: 1,
                padding: "0.75rem",
                background: "transparent",
                border: "none",
                borderBottom: active ? `2px solid ${color}` : "2px solid transparent",
                color: active ? color : "var(--text-muted)",
                fontFamily: "'DM Sans', sans-serif",
                fontWeight: active ? 600 : 400,
                fontSize: "0.875rem",
                cursor: "pointer",
                transition: "all 0.15s",
                marginBottom: "-1px",
              }}
            >
              {t === "income" ? "Gelir Ekle" : "Gider Ekle"}
            </button>
          );
        })}
      </div>

      <form onSubmit={handleSubmit} noValidate style={{
        padding: "1.25rem", display: "flex", flexDirection: "column", gap: "0.875rem",
      }}>
        {/* Category */}
        <div>
          <label style={{ display: "block", fontSize: "0.75rem", color: "var(--text-muted)", marginBottom: "0.375rem" }}>
            Kategori {errors.category && <span style={{ color: "var(--red)" }}>— {errors.category}</span>}
          </label>
          <div style={{ position: "relative" }}>
            <select
              value={category}
              onChange={e => { setCategory(e.target.value); setErrors(p => ({ ...p, category: "" })); }}
              onFocus={() => setFocusField("category")}
              onBlur={() => setFocusField("")}
              style={{
                ...inputStyle(focusField === "category", errors.category),
                appearance: "none", WebkitAppearance: "none",
                paddingRight: "2rem", cursor: "pointer",
              }}
            >
              <option value="">Seçin...</option>
              {categories.map(c => (
                <option key={c.name} value={c.name} style={{ background: "#111116" }}>{c.icon} {c.name}</option>
              ))}
            </select>
            <svg style={{
              position: "absolute", right: "0.625rem", top: "50%",
              transform: "translateY(-50%)", pointerEvents: "none", color: "var(--text-muted)",
            }} width="12" height="12" viewBox="0 0 12 12" fill="none">
              <path d="M2 4l4 4 4-4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
          </div>
        </div>

        {/* Amount */}
        <div>
          <label style={{ display: "block", fontSize: "0.75rem", color: "var(--text-muted)", marginBottom: "0.375rem" }}>
            Tutar {errors.amount && <span style={{ color: "var(--red)" }}>— {errors.amount}</span>}
          </label>
          <div style={{ position: "relative" }}>
            <span style={{
              position: "absolute", left: "0.75rem", top: "50%",
              transform: "translateY(-50%)", color: "var(--text-muted)",
              fontSize: "0.875rem", pointerEvents: "none",
            }}>₺</span>
            <input
              type="number" min="0.01" step="0.01" placeholder="0,00" value={amount}
              onChange={e => { setAmount(e.target.value); setErrors(p => ({ ...p, amount: "" })); }}
              onFocus={() => setFocusField("amount")} onBlur={() => setFocusField("")}
              style={{
                ...inputStyle(focusField === "amount", errors.amount),
                paddingLeft: "1.625rem",
                fontFamily: "'Outfit', sans-serif", fontWeight: 600, fontSize: "1rem",
              }}
            />
          </div>
        </div>

        {/* Description */}
        <div>
          <label style={{ display: "block", fontSize: "0.75rem", color: "var(--text-muted)", marginBottom: "0.375rem" }}>
            Açıklama <span style={{ color: "var(--text-dim)" }}>(opsiyonel)</span>
          </label>
          <input
            type="text" placeholder="Örn: Öğle yemeği" value={description}
            onChange={e => setDescription(e.target.value)}
            onFocus={() => setFocusField("desc")} onBlur={() => setFocusField("")}
            style={inputStyle(focusField === "desc")}
          />
        </div>

        {/* Submit */}
        <button
          type="submit"
          style={{
            width: "100%", padding: "0.625rem", borderRadius: "8px",
            background: success ? "var(--green-dim)" : type === "income" ? "var(--green-dim)" : "var(--red-dim)",
            border: `1px solid ${success ? "var(--green-border)" : type === "income" ? "var(--green-border)" : "var(--red-border)"}`,
            color: success ? "var(--green)" : type === "income" ? "var(--green)" : "var(--red)",
            fontFamily: "'DM Sans', sans-serif", fontWeight: 600, fontSize: "0.875rem",
            cursor: "pointer", transition: "all 0.15s",
          }}
        >
          {success ? "✓ Kaydedildi" : type === "income" ? "Gelir Ekle" : "Gider Ekle"}
        </button>
      </form>
    </div>
  );
}
```

## Doğrulama
- Boş submit → kategori ve tutar kırmızıya boyanır, "Seçiniz" / "Geçersiz tutar" yazısı çıkar
- Geçerli form submit → "✓ Kaydedildi" 1.8 saniye yeşil görünür, form temizlenir
- Gelir sekmesine geç → kategori dropdown'unda 4 gelir kategorisi, buton yeşil

Sonraki: [07-transaction-list-card.md](./07-transaction-list-card.md)
