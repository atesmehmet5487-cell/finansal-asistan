# 09 — Apify Market Widget (Canlı Borsa/Döviz)

## Amaç
Üst banner'da (DAViDataPanel yerine) canlı borsa kartları: BIST 100 / USD-TRY / Altın / BTC — fiyat + 24h % değişim.
Veri kaynağı: Apify üzerindeki Yahoo Finance scraper actor.

## Strateji
- Apify token `.env.local` → `VITE_APIFY_TOKEN`
- Run-sync endpoint kullan (Apify çalışıp datayı dönüş kuyruğunda verir, ekstra polling yok)
- `useApifyMarket(symbols)` custom hook → in-memory 5dk cache (sayfa yenilenmeden tekrar çağrı yapmaz)
- UI: yatay 4 mini kart, her birinde sembol etiketi + büyük fiyat (Outfit) + 24h % (yeşil ▲ / kırmızı ▼)

## Önerilen Actor
`canadesk/yahoo-finance` — Yahoo sembolleri ile çalışır:
- `XU100.IS` → BIST 100
- `TRY=X` → USD/TRY
- `GC=F` → Altın futures (oz)
- `BTC-USD` → Bitcoin

> Alternatif: `epctex/yahoo-finance-scraper`. Input şeması farklı olabilir, dokümana bakıp adapte et.

## Apify Endpoint
```
POST https://api.apify.com/v2/acts/canadesk~yahoo-finance/run-sync-get-dataset-items?token={VITE_APIFY_TOKEN}
Content-Type: application/json

{
  "symbols": ["XU100.IS", "TRY=X", "GC=F", "BTC-USD"]
}
```

Dönüş örneği (actor'a göre alan adları değişir, log'dan görüp normalize et):
```json
[
  { "symbol": "XU100.IS", "regularMarketPrice": 9842.51, "regularMarketChangePercent": 1.24 },
  { "symbol": "TRY=X",    "regularMarketPrice": 38.95,   "regularMarketChangePercent": -0.32 },
  { "symbol": "GC=F",     "regularMarketPrice": 2412.30, "regularMarketChangePercent": 0.81 },
  { "symbol": "BTC-USD",  "regularMarketPrice": 67821.0, "regularMarketChangePercent": -1.05 }
]
```

## src/hooks/useApifyMarket.ts
```ts
import { useEffect, useState } from "react";

export interface Quote {
  symbol: string;
  label: string;
  price: number;
  changePct: number;
  unit: string;
}

interface RawQuote {
  symbol: string;
  regularMarketPrice?: number;
  regularMarketChangePercent?: number;
  price?: number;
  changePercent?: number;
}

interface CacheEntry { data: Quote[]; ts: number }
const CACHE: Record<string, CacheEntry> = {};
const TTL = 5 * 60 * 1000;

const LABELS: Record<string, { label: string; unit: string }> = {
  "XU100.IS": { label: "BIST 100",  unit: ""   },
  "TRY=X":    { label: "USD / TRY", unit: "₺"  },
  "GC=F":     { label: "Altın",     unit: "$"  },
  "BTC-USD":  { label: "Bitcoin",   unit: "$"  },
};

export function useApifyMarket(symbols: string[]) {
  const [data, setData] = useState<Quote[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const key = symbols.sort().join(",");
    const hit = CACHE[key];
    if (hit && Date.now() - hit.ts < TTL) {
      setData(hit.data);
      return;
    }

    const token = import.meta.env.VITE_APIFY_TOKEN;
    if (!token) {
      setError("VITE_APIFY_TOKEN tanımlı değil");
      return;
    }

    setLoading(true);
    setError(null);

    fetch(
      `https://api.apify.com/v2/acts/canadesk~yahoo-finance/run-sync-get-dataset-items?token=${token}`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ symbols }),
      }
    )
      .then(r => {
        if (!r.ok) throw new Error(`Apify ${r.status}`);
        return r.json();
      })
      .then((raw: RawQuote[]) => {
        const quotes: Quote[] = raw.map(r => ({
          symbol: r.symbol,
          label: LABELS[r.symbol]?.label || r.symbol,
          price: r.regularMarketPrice ?? r.price ?? 0,
          changePct: r.regularMarketChangePercent ?? r.changePercent ?? 0,
          unit: LABELS[r.symbol]?.unit || "",
        }));
        CACHE[key] = { data: quotes, ts: Date.now() };
        setData(quotes);
      })
      .catch(e => setError(e.message))
      .finally(() => setLoading(false));
  }, [symbols.join(",")]);

  return { data, loading, error };
}
```

## src/components/Layout/MarketWidget.tsx
```tsx
import { TrendingUp, TrendingDown } from "lucide-react";
import { useApifyMarket } from "../../hooks/useApifyMarket";

const SYMBOLS = ["XU100.IS", "TRY=X", "GC=F", "BTC-USD"];

const formatPrice = (price: number, unit: string) => {
  const num = new Intl.NumberFormat("tr-TR", {
    minimumFractionDigits: 2, maximumFractionDigits: 2,
  }).format(price);
  return unit === "₺" ? `₺${num}` : unit === "$" ? `$${num}` : num;
};

export default function MarketWidget() {
  const { data, loading, error } = useApifyMarket(SYMBOLS);

  return (
    <div style={{
      background: "var(--bg-card)", border: "1px solid var(--border)",
      borderRadius: "12px", padding: "0.875rem 1.25rem",
      display: "flex", alignItems: "center", gap: "0.75rem", flexWrap: "wrap",
    }}>
      {/* Sol marka */}
      <div style={{ display: "flex", alignItems: "center", gap: "0.625rem", marginRight: "1rem" }}>
        <div style={{
          width: "1.75rem", height: "1.75rem", borderRadius: "6px",
          background: "var(--blue-dim)", border: "1px solid var(--blue-border)",
          display: "flex", alignItems: "center", justifyContent: "center",
          color: "var(--blue)", fontSize: "0.75rem", fontWeight: 700,
        }}>⚡</div>
        <span style={{
          fontFamily: "'Outfit', sans-serif", fontWeight: 700,
          fontSize: "0.9375rem", color: "var(--text)", letterSpacing: "-0.02em",
        }}>
          DAVi<span style={{ color: "var(--blue)" }}>Data</span>
        </span>
      </div>

      {/* Quote kartları */}
      <div style={{ display: "flex", gap: "0.5rem", flex: 1, flexWrap: "wrap" }}>
        {loading && (
          <span style={{ fontSize: "0.75rem", color: "var(--text-muted)" }}>Yükleniyor...</span>
        )}
        {error && (
          <span style={{ fontSize: "0.75rem", color: "var(--red)" }}>{error}</span>
        )}
        {!loading && !error && data.map(q => {
          const up = q.changePct >= 0;
          const color = up ? "var(--green)" : "var(--red)";
          return (
            <div key={q.symbol} style={{
              display: "flex", flexDirection: "column", gap: "0.125rem",
              padding: "0.375rem 0.75rem",
              background: "var(--bg)", border: "1px solid var(--border)",
              borderRadius: "8px", minWidth: "120px",
            }}>
              <span style={{
                fontSize: "0.625rem", color: "var(--text-muted)",
                textTransform: "uppercase", letterSpacing: "0.06em",
              }}>{q.label}</span>
              <span style={{
                fontFamily: "'Outfit', sans-serif", fontWeight: 700,
                fontSize: "0.9375rem", color: "var(--text)",
              }}>{formatPrice(q.price, q.unit)}</span>
              <span style={{
                fontSize: "0.6875rem", fontWeight: 600, color,
                display: "flex", alignItems: "center", gap: "0.125rem",
              }}>
                {up ? <TrendingUp size={10} /> : <TrendingDown size={10} />}
                {up ? "+" : ""}{q.changePct.toFixed(2)}%
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
}
```

## Dashboard'a Bağlama
`Dashboard.tsx`'te:
```tsx
import MarketWidget from "./MarketWidget";
// ...
<MarketWidget />  // DAViDataPanel yerine
```

## Env Setup
1. https://console.apify.com/account/integrations → Personal API token kopyala
2. Projeyi root'unda `.env.local` oluştur:
   ```
   VITE_APIFY_TOKEN=apify_api_xxxxxxxxxxxx
   ```
3. Dev server'ı restart et (env değişiklikleri için).

## Test
```bash
# Önce kabuktan deneyerek dönen JSON şemasını gör:
curl -X POST \
  "https://api.apify.com/v2/acts/canadesk~yahoo-finance/run-sync-get-dataset-items?token=$VITE_APIFY_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"symbols":["XU100.IS","TRY=X","GC=F","BTC-USD"]}'
```
Eğer alan adları farklıysa `useApifyMarket.ts`'teki `r.regularMarketPrice` / `r.regularMarketChangePercent` kısımlarını dönen şemaya göre güncelle.

## Maliyet & Limit Notları
- Apify free plan: aylık $5 kredi — basit Yahoo Finance scrape'i 0.001-0.01$ civarı, günde yüzlerce çağrıya yetmeli
- 5dk cache aynı sayfa session'unda gereksiz çağrıyı önler
- Daha agresif refresh istersen `setInterval(fetch, 60_000)` ekle (1dk'da bir)

## Doğrulama
- Sayfa açılınca üstte 4 kart yüklenir
- Her kart: BIST 100 / USD-TRY / Altın / Bitcoin etiketleri + güncel fiyat + yeşil/kırmızı yüzde
- Yeniden yüklemede 5dk içinde cache'ten gelir (hızlı)
- Token boşsa kırmızı "VITE_APIFY_TOKEN tanımlı değil" mesajı

Sonraki (opsiyonel): [10-master-prompt.md](./10-master-prompt.md) — her şeyi tek prompt'ta verir
