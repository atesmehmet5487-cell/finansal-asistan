# 05 — Summary Cards (Gelir / Gider / Bakiye)

## Amaç
3 sütunda özet kart: başlık + ikon + büyük tutar. Variant'a göre renk; negatif bakiye otomatik kırmızı.

## Dosya
`src/components/Cards/SummaryCard.tsx`

## Görsel
```
┌──────────────────────────────┐
│ TOPLAM GELİR          [🟢↑] │
│                              │
│  ₺2.450,00                   │
└──────────────────────────────┘
```
- Sol üstte uppercase başlık (text-muted, letter-spacing 0.06em)
- Sağ üstte 2rem kare ikon badge (variant-dim bg)
- Aşağıda Outfit 1.625rem 700 weight tutar (variant rengi)
- Hover: border `var(--border)` → variant-border'a geçer (0.15s)

## Variants
```ts
const variants = {
  income:  { color: "var(--green)", dim: "var(--green-dim)", border: "var(--green-border)" },
  expense: { color: "var(--red)",   dim: "var(--red-dim)",   border: "var(--red-border)"   },
  balance: { color: "var(--blue)",  dim: "var(--blue-dim)",  border: "var(--blue-border)"  },
};
// Eğer variant === "balance" && amount < 0 → expense variant'a düş (kırmızı)
```

## src/components/Cards/SummaryCard.tsx (TAM)
```tsx
import type { ReactNode } from "react";
import { formatCurrency } from "../../utils/categories";

interface SummaryCardProps {
  title: string;
  amount: number;
  icon: ReactNode;
  variant: "income" | "expense" | "balance";
}

const variants = {
  income:  { color: "var(--green)",  dim: "var(--green-dim)",  border: "var(--green-border)" },
  expense: { color: "var(--red)",    dim: "var(--red-dim)",    border: "var(--red-border)"   },
  balance: { color: "var(--blue)",   dim: "var(--blue-dim)",   border: "var(--blue-border)"  },
};

export default function SummaryCard({ title, amount, icon, variant }: SummaryCardProps) {
  const v = (variant === "balance" && amount < 0)
    ? { color: "var(--red)", dim: "var(--red-dim)", border: "var(--red-border)" }
    : variants[variant];

  return (
    <div
      className="fade-up"
      style={{
        background: "var(--bg-card)",
        border: "1px solid var(--border)",
        borderRadius: "12px",
        padding: "1.25rem",
        transition: "border-color 0.15s",
        cursor: "default",
      }}
      onMouseEnter={e => (e.currentTarget.style.borderColor = v.border)}
      onMouseLeave={e => (e.currentTarget.style.borderColor = "var(--border)")}
    >
      <div style={{
        display: "flex", alignItems: "center", justifyContent: "space-between",
        marginBottom: "1rem",
      }}>
        <span style={{
          fontSize: "0.75rem", fontWeight: 500, color: "var(--text-muted)",
          textTransform: "uppercase", letterSpacing: "0.06em",
        }}>
          {title}
        </span>
        <div style={{
          width: "2rem", height: "2rem", borderRadius: "8px",
          background: v.dim,
          display: "flex", alignItems: "center", justifyContent: "center",
        }}>
          {icon}
        </div>
      </div>
      <p style={{
        fontFamily: "'Outfit', sans-serif", fontSize: "1.625rem", fontWeight: 700,
        color: v.color, letterSpacing: "-0.03em",
      }}>
        {formatCurrency(amount)}
      </p>
    </div>
  );
}
```

## Kullanım
```tsx
import { TrendingUp, TrendingDown, Wallet } from "lucide-react";

<SummaryCard title="Toplam Gelir" amount={income}  icon={<TrendingUp   size={15} color="var(--green)" />} variant="income"  />
<SummaryCard title="Toplam Gider" amount={expense} icon={<TrendingDown size={15} color="var(--red)"   />} variant="expense" />
<SummaryCard title="Net Bakiye"   amount={balance} icon={<Wallet       size={15} color="var(--blue)"  />} variant="balance" />
```

## Doğrulama
- 3 kart yan yana, eşit genişlikte
- Mouse üzerine gelince kenar rengi değişir
- `balance = -100` → mavi yerine kırmızı görünür

Sonraki: [06-transaction-form.md](./06-transaction-form.md)
