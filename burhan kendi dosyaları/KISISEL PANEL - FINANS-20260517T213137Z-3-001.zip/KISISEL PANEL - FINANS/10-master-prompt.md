# 10 — Master Prompt (Tek Atışta Tam Proje)

> Bu dosyayı bir AI asistana (Claude / GPT / Cursor) verirsen sıfırdan tüm projeyi tek seferde inşa edebilir.

---

## SİSTEM PROMPTU

Sen, kıdemli bir frontend mühendisisin. **React 19 + TypeScript + Vite + Tailwind 4 + Recharts** stack'i ile **Türkçe arayüzlü, koyu temalı kişisel finans takip uygulaması** yazacaksın. Tüm kod **inline `React.CSSProperties`** kullanır (Tailwind utility class kullanma). Tema renkleri `:root` CSS değişkenleri ile yönetilir. Tüm dosyaları tek mesajda, eksiksiz olarak ver.

## GÖREV

Aşağıdaki yapıda projeyi oluştur:

### 1) `package.json`
- deps: `react ^19.2`, `react-dom ^19.2`, `recharts ^3.7`, `lucide-react ^0.575`, `clsx ^2.1`, `tailwind-merge ^3.5`, `class-variance-authority ^0.7`
- devDeps: `vite ^7.3`, `@vitejs/plugin-react ^5.1`, `typescript ~5.9`, `tailwindcss ^4.2`, `@tailwindcss/vite ^4.2`, `@types/react`, `@types/react-dom`, `@types/node`, eslint stack

### 2) `vite.config.ts`
```ts
import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import tailwindcss from '@tailwindcss/vite'
export default defineConfig({ plugins: [react(), tailwindcss()] })
```

### 3) `index.html`
Google Fonts: `Outfit` (400/500/600/700) + `DM Sans` (400/500/600). Title: "Kişisel Finans Takip". Lang: "tr".

### 4) `src/index.css`
- `@import "tailwindcss"`
- `:root` içinde renk değişkenleri:
  - `--bg #09090B`, `--bg-card #111116`, `--bg-hover #18181F`
  - `--border #27272A`, `--border-light #1C1C22`
  - `--text #FAFAFA`, `--text-muted #71717A`, `--text-dim #3F3F46`
  - `--blue #60A5FA` (+ dim `rgba(96,165,250,0.08)`, border `rgba(96,165,250,0.18)`)
  - `--green #4ADE80` (+ dim/border benzer alpha)
  - `--red #F87171` (+ dim/border benzer alpha)
- Global reset (margin/padding 0, box-sizing border-box)
- `html, body, #root`: bg `var(--bg)`, font `'DM Sans', system-ui, sans-serif`, 14px, line-height 1.5
- `h1,h2,h3,h4`: `'Outfit', sans-serif`, letter-spacing `-0.02em`
- Custom scrollbar (4px, `var(--border)`)
- `input[type="number"]` spinner gizle
- `@keyframes fadeUp` + `.fade-up` class (0.2s)
- Media: `.grid-3` ve `.grid-2` ≤640px'te `1fr`; `.grid-2` 641-900px arası `1fr`

### 5) `src/types/finance.ts`
```ts
export type TransactionType = "income" | "expense";
export interface Transaction {
  id: string;
  type: TransactionType;
  category: string;
  amount: number;
  description: string;
  date: string;       // "YYYY-MM-DD"
  createdAt: number;  // Date.now()
}
export interface CategoryConfig { name: string; color: string; icon: string; }
```

### 6) `src/utils/categories.ts`
- `expenseCategories`: 8 öğe
  - Yeme-İçme `#FB7185` 🍔, Ulaşım `#A78BFA` 🚗, Alışveriş `#22D3EE` 🛍️, Faturalar `#FB923C` 📄, Eğlence `#F472B6` 🎮, Sağlık `#4ADE80` 💊, Eğitim `#60A5FA` 📚, Diğer `#94A3B8` 📌
- `incomeCategories`: 4 öğe
  - Maaş `#34D399` 💰, Freelance `#2DD4BF` 💻, Yatırım `#FBBF24` 📈, Diğer Gelir `#A3E635` 🎁
- `getCategoryConfig(name, type)` → CategoryConfig | undefined
- `formatCurrency(amount)` → `Intl.NumberFormat("tr-TR", { style: "currency", currency: "TRY", minimumFractionDigits: 2 })`

### 7) `src/lib/utils.ts`
```ts
import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";
export function cn(...inputs: ClassValue[]) { return twMerge(clsx(inputs)); }
```

### 8) `src/main.tsx` + `src/App.tsx`
- `main.tsx`: `StrictMode + createRoot + ./index.css + <App />`
- `App.tsx`: sadece `<Dashboard />` render eder

### 9) `src/components/Layout/Dashboard.tsx`
- State: `useState<Transaction[]>([])`, `add`, `del`
- Computed: `income`, `expense`, `balance`
- Sticky navbar (52px, bg `rgba(9,9,11,0.85)`, backdrop-filter blur 12px):
  - Sol: 26px mavi badge (🏦) + "Finans Takip" (Outfit 700)
  - Sağ: 📅 + ay/yıl, sonra (varsa) mavi pill "{n} işlem"
- Body: `max-width: 1280px`, padding `1.5rem`
- `<MarketWidget />` (banner)
- `.grid-3`: 3 SummaryCard (Toplam Gelir/Gider/Net Bakiye, ikonlar `TrendingUp/TrendingDown/Wallet`)
- `.grid-2`: sol `<TransactionList>`, sağ 320px sidebar → `<ExpensePieChart>` üstte, `<TransactionForm>` altta
- Footer: "Veriler yerel bellekte tutulur — sayfa yenilenince sıfırlanır"

### 10) `src/components/Cards/SummaryCard.tsx`
- Props: `{ title, amount, icon, variant: "income"|"expense"|"balance" }`
- Variants → variant rengi (green/red/blue). Bakiye negatifse → kırmızı.
- 12px radius, 1.25rem padding, hover'da border renge döner (0.15s)
- Üstte uppercase başlık (text-muted, ls 0.06em) + sağda 2rem dim badge'li ikon
- Altta Outfit 1.625rem 700 weight, variant rengi, ls `-0.03em`, `formatCurrency`
- `.fade-up` class

### 11) `src/components/Forms/TransactionForm.tsx`
- Props: `{ onAdd: (tx) => void }`
- State: `type`, `category`, `amount`, `description`, `errors`, `success`, `focusField`
- Tab header (Gider/Gelir), aktif olanın altında 2px renkli çizgi
- 3 alan: kategori (select, ▾ icon), tutar (₺ prefix, Outfit), açıklama (text)
- `inputStyle(focus, error)`: border kırmızı (error) > mavi (focus) > border
- Validation: kategori boş veya tutar ≤ 0 → inline kırmızı mesaj
- Submit: `Transaction` oluştur (id = `crypto.randomUUID()`), formu reset, 1.8s "✓ Kaydedildi" yeşil

### 12) `src/components/Cards/TransactionCard.tsx`
- Props: `{ transaction, onDelete }`
- Sol: kategori icon (2rem, bg `${color}12`)
- Orta: description (yoksa category) + "{category} · {DD MMM}" (Türkçe)
- Sağ: Outfit 700, gelirde +yeşil, giderde -kırmızı
- Hover: bg `var(--bg-hover)`, sil butonu opacity 0→1
- Sil iki aşama: Trash2 → ✓/✕

### 13) `src/components/Lists/TransactionList.tsx`
- Props: `{ transactions, onDelete }`
- Sort `createdAt` desc
- Header: "İşlemler" + count badge
- Empty: 📋 + "Henüz işlem yok" + "Sağdaki formdan ekleyebilirsiniz"
- Kartlar arası 1px `var(--border-light)` divider (margin 0 1rem)

### 14) `src/components/Charts/ExpensePieChart.tsx`
- Props: `{ transactions }`
- Tab: Gider | Gelir (segmented, aktif arkaplan `var(--bg-hover)`)
- Data: `Map` ile kategori bazlı toplam + yüzde + value desc sort
- Recharts `PieChart` + `Pie` (innerRadius 55, outerRadius 85, paddingAngle 2, animationDuration 450, strokeWidth 0) + `Cell` her dilim
- Center `<g>` (2 text): TOPLAM GİDER/GELİR + tutar
- Custom Tooltip: icon, name, tutar, %
- Legend rows: 6px renkli daire + name + % + tutar
- Empty: 📊 + "Henüz veri yok"

### 15) `src/hooks/useApifyMarket.ts`
- Apify `canadesk/yahoo-finance` actor'a `run-sync-get-dataset-items` ile POST
- Endpoint: `https://api.apify.com/v2/acts/canadesk~yahoo-finance/run-sync-get-dataset-items?token={VITE_APIFY_TOKEN}`
- Body: `{ symbols }`
- In-memory `CACHE` objesi, 5 dakika TTL
- Dönen rawQuote'ları normalize → `{ symbol, label, price, changePct, unit }`
- LABELS: XU100.IS = "BIST 100", TRY=X = "USD / TRY" (₺), GC=F = "Altın" ($), BTC-USD = "Bitcoin" ($)
- Token yoksa hata mesajı

### 16) `src/components/Layout/MarketWidget.tsx`
- `useApifyMarket(["XU100.IS","TRY=X","GC=F","BTC-USD"])`
- Sol marka: 1.75rem mavi badge (⚡) + "DAVi**Data**" (Data mavi)
- 4 mini quote kartı (minWidth 120px, bg `var(--bg)`, border): uppercase label + Outfit fiyat + yeşil/kırmızı yüzde (TrendingUp/Down icon)

### 17) `.env.local`
```
VITE_APIFY_TOKEN=apify_api_xxxxxxxxxxxx
```

### 18) `.gitignore`
node_modules, dist, .env, .env.local, .DS_Store, *.log

## KURALLAR
1. Tüm yazılar Türkçe (Toplam Gelir, Gider, Bakiye, Kategori, Tutar, vb.)
2. ID hep `crypto.randomUUID()`, para hep `formatCurrency`, tarih hep `toLocaleDateString("tr-TR", ...)`
3. Inline stil zorunlu, Tailwind class yok (sadece `@import "tailwindcss"` reset için)
4. Animasyon ve transition'lar 0.1-0.2s
5. Mobile responsive (`.grid-3` / `.grid-2` class'larıyla)

## ÇIKTI
Her dosyayı ayrı kod bloğu olarak (dosya yolu başlık), tüm proje çalışacak şekilde, tek mesajda ver. Eksik bırakma — tüm 14 component dosyası + utils + types + hook + config.

---

## BONUS: Hızlı Test
```bash
git clone <repo> finans-takip && cd finans-takip
npm install
echo "VITE_APIFY_TOKEN=$YOUR_TOKEN" > .env.local
npm run dev
# → http://localhost:5173
```

Beklenen ilk açılış:
1. Üstte navbar (logo + ay)
2. Banner'da 4 borsa kartı (BIST/USD-TRY/Altın/BTC) — Apify'dan canlı
3. 3 boş özet kart (₺0,00 hepsi)
4. Sol: 📋 empty state, Sağ: 📊 empty state + boş form
5. Form'dan "Yeme-İçme ₺50" ekle → liste, donut, gider kartı anında güncellenir
